# SMS Spam Detection — NLP Assignment 1

# Course: Introduction to NLP  
# Phase: Data Acquisition, Text Processing & Cleaning  
# Topic: SMS Spam Detection  
# Prediction target: `spam` or `ham`

## Dataset
- Name: UCI SMS Spam Collection
- Source: https://archive.ics.uci.edu/dataset/228/sms+spam+collection
- Download URL used by the script: https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip
- Licence: Creative Commons Attribution 4.0 International (CC BY 4.0).
- Citation: Almeida, T. & Hidalgo, J. (2011). *SMS Spam Collection*. UCI Machine Learning Repository. https://doi.org/10.24432/C5CC84


# Environment 
Python 3.11 .

python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

python -m pip install --upgrade pip
pip install -r requirements.txt


## Run the project
Run these commands from the repository root:

# bash
python src/exploration.py
python src/pipeline.py


Outputs:
- `outputs/exploration_stats.json` — document, label, length and tokenizer statistics.
- `outputs/label_distribution.png` — class distribution chart.
- `outputs/cleaned_sms.csv` — cleaned messages and labels for Phase 2.
- `outputs/cleaning_stats.json` — raw vs cleaned vocabulary sizes.


# NLP methods
1. Unicode NFC normalization.
2. Lowercase conversion.
3. URL, email and phone-number removal.
4. Removal of non-alphabetic noise and repeated whitespace.
5. Stop-word removal while preserving `no`, `nor`, `not` and `never`.
6. Porter stemming.
7. Regex tokenizer and NLTK Treebank tokenizer comparison in the exploration script.

# Regular expressions
- URL: `(https?://\S+|www\.\S+)`
- Email: `\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b`
- Phone: `\+?\d[\d\s().-]{7,}\d`

These are practical patterns for common SMS noise. They are not intended to validate every possible URL, email or international phone format.

# Repository structure
``text
SMS_Spam_NLP_Assignment/
├── data/raw/                 
├── notebooks/
│   └── exploration.ipynb
├── outputs/                 
├── src/
│   ├── download_data.py
│   ├── exploration.py
│   ├── cleaning.py
│   └── pipeline.py
├── .gitignore
├── requirements.txt
└── README.md
