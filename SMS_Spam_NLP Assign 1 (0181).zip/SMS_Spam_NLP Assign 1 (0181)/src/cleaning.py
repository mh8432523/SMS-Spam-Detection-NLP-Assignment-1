import re
import unicodedata
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords

stemmer = PorterStemmer()
NEGATIONS = {"no", "nor", "not", "never"}
def get_stop_words():
    return set(stopwords.words("english")) - NEGATIONS

URL_RE = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
PHONE_RE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
NON_ALPHA_RE = re.compile(r"[^a-zA-Z\s]")
MULTISPACE_RE = re.compile(r"\s+")

def clean_text(text):

    text = unicodedata.normalize("NFC", str(text))
    text = text.lower()
    text = URL_RE.sub(" ", text)
    text = EMAIL_RE.sub(" ", text)
    text = PHONE_RE.sub(" ", text)
    text = NON_ALPHA_RE.sub(" ", text)
    text = MULTISPACE_RE.sub(" ", text).strip()
    stop_words = get_stop_words()
    tokens = [word for word in text.split()
              if word not in stop_words and len(word) > 1]
    tokens = [stemmer.stem(word) for word in tokens]
    return " ".join(tokens)
