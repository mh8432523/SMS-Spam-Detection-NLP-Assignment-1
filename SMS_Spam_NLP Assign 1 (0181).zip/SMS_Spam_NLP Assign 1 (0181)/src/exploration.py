from collections import Counter
from pathlib import Path
import json
import re
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.tokenize import TreebankWordTokenizer
from download_data import download_dataset

def main():
    path = download_dataset()
    df = pd.read_csv(path, sep="\t", header=None, names=["label", "text"],
                     encoding="latin-1")
    df = df.dropna(subset=["text", "label"]).copy()
    df["word_count"] = df["text"].astype(str).apply(lambda x: len(x.split()))
    sample = df["text"].astype(str).head(1000).tolist()
    regex_tokens = re.findall(r"\b[\w']+\b", " ".join(sample).lower())
    nltk_tokenizer = TreebankWordTokenizer()
    nltk_tokens = [t.lower() for msg in sample for t in nltk_tokenizer.tokenize(msg)]
    vocab_before = len(set(regex_tokens))
    stats = {
        "documents": int(len(df)),
        "average_words_per_document": round(float(df["word_count"].mean()), 2),
        "label_distribution": {str(k): int(v) for k, v in df["label"].value_counts().items()},
        "sample_documents_for_vocabulary": len(sample),
        "regex_tokens_in_sample": len(regex_tokens),
        "regex_types_in_sample": vocab_before,
        "nltk_tokens_in_sample": len(nltk_tokens),
        "nltk_types_in_sample": len(set(nltk_tokens)),
        "messy_examples": df["text"].astype(str).head(5).tolist()
    }
    Path("outputs").mkdir(exist_ok=True)
    Path("outputs/exploration_stats.json").write_text(
        json.dumps(stats, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    counts = df["label"].value_counts()
    plt.figure(figsize=(6,4))
    counts.plot(kind="bar")
    plt.title("SMS label distribution")
    plt.xlabel("Label")
    plt.ylabel("Number of messages")
    plt.tight_layout()
    plt.savefig("outputs/label_distribution.png", dpi=160)
    print(json.dumps(stats, indent=2))
    print("Saved outputs/exploration_stats.json and label_distribution.png")

if __name__ == "__main__":
    main()
