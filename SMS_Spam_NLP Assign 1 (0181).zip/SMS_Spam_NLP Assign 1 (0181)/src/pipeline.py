from pathlib import Path
import pandas as pd
import nltk
from download_data import download_dataset

def prepare_nltk():
    nltk.download("stopwords", quiet=True)

def load_data():
    path = download_dataset()
    df = pd.read_csv(path, sep="\t", header=None, names=["label", "text"],
                     encoding="latin-1")
    return df

def main():
    prepare_nltk()
    df = load_data()
    df = df.dropna(subset=["text", "label"]).copy()
    from cleaning import clean_text
    df["clean_text"] = df["text"].apply(clean_text)
    raw_vocab = set(word.lower() for msg in df["text"].astype(str) for word in msg.split())
    clean_vocab = set(word for msg in df["clean_text"].astype(str) for word in msg.split())
    import json
    Path("outputs/exploration_stats.json").parent.mkdir(exist_ok=True)
    stats_path = Path("outputs/cleaning_stats.json")
    stats_path.write_text(json.dumps({
        "raw_vocabulary_size_whitespace_tokens": len(raw_vocab),
        "cleaned_vocabulary_size": len(clean_vocab)
    }, indent=2), encoding="utf-8")
    print(f"Vocabulary before cleaning: {len(raw_vocab)}")
    print(f"Vocabulary after cleaning: {len(clean_vocab)}")
    Path("outputs").mkdir(exist_ok=True)
    df[["label", "clean_text"]].to_csv(
        "outputs/cleaned_sms.csv", index=False, encoding="utf-8"
    )
    print(f"Raw documents: {len(df)}")
    print("Label distribution:")
    print(df["label"].value_counts().to_string())
    print("Saved: outputs/cleaned_sms.csv")

if __name__ == "__main__":
    prepare_nltk()
    main()
