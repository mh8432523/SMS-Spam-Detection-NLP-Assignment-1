from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import urllib.request

DATA_DIR = Path("data/raw")
DATA_DIR.mkdir(parents=True, exist_ok=True)
URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/00228/smsspamcollection.zip"

def download_dataset():
    target = DATA_DIR / "SMSSpamCollection"
    if target.exists():
        print(f"Dataset already exists: {target}")
        return target
    print("Downloading UCI SMS Spam Collection...")
    request = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=60) as response:
        archive_bytes = response.read()
    with ZipFile(BytesIO(archive_bytes)) as archive:
        member = next(name for name in archive.namelist()
                      if name.endswith("SMSSpamCollection"))
        target.write_bytes(archive.read(member))
    print(f"Saved dataset to {target}")
    return target

if __name__ == "__main__":
    download_dataset()
